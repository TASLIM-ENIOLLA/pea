<?php

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadAdminData.php';

    $section = '
        <div class="py-4 px-3 w-100 h-100 flex-v">
            <div class="p-3 theme-color">
                <h4 class="bold text-capitalize">edit profile</h4>
            </div>
            <form action = "" method = "POST" enctype = "multipart/form-data" class = "flex-h flex-1 overflow-y-auto flex-wrap pt-3">
                <div class = "col-12">
                    <div class = "bg-light p-3 rounded-lg mb-4 border flex-v j-c-c a-i-c">
                        <img id = "profile_img_preview" src = "' . $LoadAdminData -> validate_profile_img(ADMIN["profile_img"]) . '" class="d-block border shadow-sm p-0 rounded-lg mx-auto col-10" style = "max-width: 280px;"/>
                        <label for = "profile_img" class = "text-c pt-3 underline cursor-pointer d-block theme-color text-capitalize">
                            change profile image
                            <input type = "file" id = "profile_img" name = "profile_img" hidden />
                        </label>
                    </div>
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">First name</span>
                    <input value = "' . ADMIN["f_name"] . '" name = "f_name" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Last name</span>
                    <input value = "' . ADMIN["l_name"] . '" name = "l_name" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Mobile number</span>
                    <input value = "' . ADMIN["mobile_number"] . '" name = "mobile_number" placeholder = "+[Country Code] [Phone Number]" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Email address</span>
                    <input value = "' . ADMIN["email"] . '" name = "email_address" type = "email" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Change password (Optional)</span>
                    <input placeholder = "*********" name = "password" type = "password" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                    <span class = "bold">Confirm password (Optional)</span>
                    <input placeholder = "*********" name = "c_password" type = "password" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                </div>
                <div class = "my-3 p-3 col-12">
                    <input type = "submit" name = "edit_profile" class = "p-3 transit disabled d-block w-100 theme-bg border-0 rounded shadow text-c bold text-white" value = "Save Changes"/>
                </div>
            </form>
        </div>

        <script src = "../assets/js/frosteddialog.js"></script>
        <script src = "../assets/js/admin/edit_profile.js"></script>
    ';

    include "template/template.php";

?>
