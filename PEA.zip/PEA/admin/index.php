<?php

    include "../assets/php/init.php";
    include "../assets/php/processes/admin/LoadAdminData.php";

    $section = '
        <div class="py-4 px-3">
            <div class="p-3 theme-color">
                <h4 class="bold text-capitalize">Welcome ' . ADMIN["f_name"] . '</h4>
            </div>
            <div class="flex-h w-100 flex-wrap text-muted" style="align-items: start;">
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="all_products.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-th-list"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">all products</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="add_product.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-plus-square"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">add product</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="category.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-bars"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">category</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="analytics.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-bar-chart"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">analytics</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="edit_profile.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-user"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">edit profile</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="expiring_products.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-trash-o"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">expiring products</span>
                        </div>
                    </a>
                </div>
                <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                    <a href="logout.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg text-danger bg-light shadow flex-h a-i-c">
                        <div class="px-3">
                            <span class="fa fa-2x fa-power-off"></span>
                        </div>
                        <div class="flex-h flex-1">
                            <span class="flex-1 single-line text-capitalize bold">logout</span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    ';

    include "template/template.php";

?>
