<?php

    if(!isset($_GET["product_id"])){
        header("Location: /");
    }

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadProductData.php';


    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 flex-h a-i-c">
                <a href = "all_products.php"><h4 class="bold theme-color text-capitalize">All Products |&nbsp;</h4></a>
                <h4 class="bold text-secondary text-capitalize">' .  $LoadProductData -> product_data["name"] . '</h4>
            </div>
            <div class = "p-3 flex-1 overflow-y-auto">
                ' . $LoadProductData -> display_product_data() . '
            </div>
        </div>

        <script src = "../assets/js/admin/view_product.js"></script>
    ';

    include "template/template.php";

?>
