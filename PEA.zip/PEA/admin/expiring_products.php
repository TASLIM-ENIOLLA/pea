<?php

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadExpiringProducts.php';


    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 flex-h a-i-c">
                <h4 class="bold theme-color text-capitalize">Expiring Products</h4>
            </div>
            <div class = "p-3 flex-1 flex-v overflow-y-auto">
                ' . $LoadExpiringProducts -> render() . '
            </div>
        </div>
    ';

    include "template/template.php";

?>
