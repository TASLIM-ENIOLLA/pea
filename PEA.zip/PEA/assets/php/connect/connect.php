<?php

    $connect = new mysqli(
        "localhost",
        "root",
        "",
        "pea"
    );

    if($connect -> connect_error){
        die("Connection failed: " . $connect -> connect_error);
    }

    session_start();

?>
