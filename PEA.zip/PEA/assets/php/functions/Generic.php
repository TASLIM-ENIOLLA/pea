<?php

    try{
        class Generic{
            function __construct($arg = false){
                if($arg == true){
                    echo "Generic class has been called";
                }
            }
            public function filterInput($var){
                global $connect;
                $var = trim($var);
                $var = htmlspecialchars($var);
                $var = stripslashes($var);
                $var = strip_tags($var);
                $var = mysqli_real_escape_string($connect, $var);
                // $var = strtolower($var);
                return $var;
            }
            public function filterInput2($var){
                global $connect;
                $var = trim($var);
                $var = htmlspecialchars($var);
                $var = stripslashes($var);
                $var = strip_tags($var);
                // $var = mysqli_real_escape_string($connect, $var);
                // $var = strtolower($var);
                return $var;
            }

            public function forbiddenChars($string, $type = null){
                if($type == "name" || $type == null){
                    return preg_match("/[^0-9a-zA-Z_\-\s]/", $string);
                }
        		elseif($type == "text"){
                    return preg_match("/[^0-9a-zA-Z_\/\r\s\-\+\,\!\.]/", $string);
                }
        		elseif($type == "number"){
                    return preg_match("/[^0-9\,\.]/", $string);
                }
                elseif($type == "password"){
                    return preg_match("/[^0-9a-zA-Z_]/", $string);
                }
            }

            public function randomTextGen($no_of_chars){
                $rr = '';
                for($x = 0; strlen($rr) < $no_of_chars; $x++){
                    $re = mt_rand(48, 90);
                    if($re < 58 || $re > 64){
                        $re = dechex($re);
                        $re = pack("H*", $re);
                        $rr .= $re;
                    }
                }
                // $rr = strtolower($rr);
                return $rr;
            }

            public function product_id_gen(){
                global $connect;

                $a = "PRDT-" . strtolower($this -> randomTextGen(15));
                $q = $connect -> query("SELECT * FROM products WHERE id = '$a'");

                if($q -> num_rows > 0){
                    $this -> product_id_gen();
                }
                else{
                    return $a;
                }
            }

            public function category_id_gen(){
                global $connect;

                $a = "cat-" . strtolower($this -> randomTextGen(16));
                $q = $connect -> query("SELECT * FROM category WHERE id = '$a'");

                if($q -> num_rows > 0){
                    $this -> category_id_gen();
                }
                else{
                    return $a;
                }
            }
        }

        $Generic = new Generic();
    }
    catch(Exception $e){
        die("Couldn't compile generic class: " . $e);
    }

?>
