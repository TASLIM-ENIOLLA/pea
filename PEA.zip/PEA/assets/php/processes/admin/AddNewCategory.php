<?php

    include "../../init.php";

    class AddNewCategory{
        public function __construct(){
            global $connect;
            global $Generic;

            if(!empty($_GET)){
                $author = json_decode($_COOKIE["PEA"]) -> id;
                $category_id = $Generic -> category_id_gen();
                $category_name = $Generic -> filterInput($_GET["name"]);
                $category_description = $Generic -> filterInput2($_GET["description"]);

                if(strlen($category_name) > 50){
                    echo json_encode(array(
                        "type" => "error",
                        "message" => "category name too long! Max. of (50) characters."
                    ));
                }
                else{
                    $query = $connect -> query(
                        "INSERT INTO category SET id = '$category_id', name = '$category_name', author = '$author'" . ((strlen($category_description) > 0) ? ", description='$category_description'" : "")
                    );

                    if($query){
                        echo json_encode(array(
                            "type" => "success",
                            "message" => "Category added successfully!"
                        ));
                    }
                    else{
                        echo json_encode(array(
                            "type" => "error",
                            "message" => "Something went wrong! Try again."
                        ));
                    }
                }
            }
        }
    }

    $AddNewCategory = new AddNewCategory();

?>
