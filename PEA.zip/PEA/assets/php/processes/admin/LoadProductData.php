<?php

    class LoadProductData{
        function __construct(){
            global $connect;

            if(isset($_GET["product_id"])){
                $this -> product_id = $product_id = $_GET["product_id"];

                $query = $connect -> query(
                    "SELECT * FROM products WHERE id = '$product_id'"
                );

                if($query && $query -> num_rows > 0){
                    $this -> product_data = $query -> fetch_assoc();
                    $this -> product_data["image"] = (($this -> product_data["image"] == null) ? "img/default.png" : $this -> product_data["image"]);
                    $this -> display_product_data();
                }
                else{
                    $this -> product_data = null;
                    $this -> product_not_found();
                }
            }
        }

        private function format_due_date($todays_date = null, $expr_date = null){
            $todays_date = (($todays_date) ? $todays_date : date("Y-m-d h:i:s"));
            $expr_date = (($expr_date) ? $expr_date : $this -> product_data["expiration_date"]);

            $diff = date_diff(date_create($todays_date), date_create($expr_date));

            $y = $diff -> y;
            $m = $diff -> m;
            $d = $diff -> d;
            $res = "";

            if($y > 0){
                $res .= (($y == 1) ? $y . " year" : $y . " years");

                if($m > 0){
                    $res .= ", ";
                }
            }

            if($m > 0){
                $res .= (($m == 1) ? $m . " month" : $m . " months");


                if($d > 0){
                    $res .= ", ";
                }
            }

            if($d > 0){
                $res .= (($d == 1) ? $d . " day" : $d . " days");
            }

            return $res;
        }

        public function display_product_data(){
            if($this -> product_data != null){
                return '
                    <div class = "flex-h flex-1 overflow-y-auto flex-wrap pt-3">
                        <div class = "col-12">
                            <div class = "bg-light p-3 rounded-lg mb-4 border flex-v j-c-c a-i-c">
                                <img id = "profile_img_preview" src = "' . ((file_exists("../assets/" . $this -> product_data["image"])) ? "../assets/" . $this -> product_data["image"] : "../assets/img/corrupt_img.png") . '" class="d-block border shadow-sm p-0 rounded-lg mx-auto col-10" style = "max-width: 280px;"/>
                            </div>
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Product name</span>
                            <input readonly value = "' . $this -> product_data["name"] . '" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Quantity</span>
                            <input readonly value = "' . $this -> product_data["quantity"] . ' units" placeholder = "+[Country Code] [Phone Number]" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Buy price (₦)</span>
                            <input readonly value = "' . $this -> product_data["buy_price"] . '" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Sell price (₦)</span>
                            <input readonly value = "' . $this -> product_data["sell_price"] . '" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Production date</span>
                            <input readonly value = "' . date("M d Y, h:i:s", strtotime($this -> product_data["production_date"])) . '" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Expiration date</span>
                            <input readonly value = "' . date("M d Y, h:i:s", strtotime($this -> product_data["expiration_date"])) . ' (Due in ' . $this -> format_due_date() . ')" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Product description</span>
                            <textarea readonly class = "p-3 border my-2 resize-0 rounded d-block w-100 outline-0">' . ((strlen($this -> product_data["description"]) > 0) ? $this -> product_data["description"] : "-- No description available --") . '</textarea>
                        </div>
                        <div class = "col-12 pt-4">
                            <a href = "add_product.php?action=edit_product&product_id=' . $this -> product_data["id"] . '" class = "theme-border theme-bg text-capitalize bold text-white text-c d-block w-100 rounded-lg p-3">
                                edit product info
                            </a>
                        </div>
                        <div class = "col-12 pt-4">
                            <a href = "javascript:void(0);" onclick = "delete_product(this)" data-product-id = "' . $this -> product_data["id"] . '" class = "bg-danger text-capitalize bold text-white text-c d-block w-100 rounded-lg p-3">
                                delete product
                            </a>
                        </div>
                    </div>
                ';
            }
            else{
                return '
                    <div class = "p-5 bg-light shadow-sm text-c rounded-lg text-muted bold">
                        This product was not found on the database!
                    </div>
                ';
            }
        }

        public function product_not_found(){
            return '
                <div class = "bg-light p-5 text-secondary bold text-c shadow-sm">

                </div>
            ';
        }
    }

    $LoadProductData = new LoadProductData();

?>
