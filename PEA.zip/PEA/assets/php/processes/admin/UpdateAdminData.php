<?php
    include '../../init.php';

    class UpdateAdminData{
        public function __construct(){
            global $Generic;

            if(isset($_POST) && count($_POST) > 0){
                $f_name = $Generic -> filterInput($_POST["f_name"]);
                $l_name = $Generic -> filterInput($_POST["l_name"]);
                $mobile_number = $Generic -> filterInput($_POST["mobile_number"]);
                $email_address = $Generic -> filterInput($_POST["email_address"]);
                $current_password = $Generic -> filterInput($_POST["current_password"]);
                $password = $Generic -> filterInput($_POST["password"]);
                $c_password = $Generic -> filterInput($_POST["c_password"]);

                $profile_img_file = ((!empty($_FILES)) ? $_FILES["profile_img"] : null);

                $this -> admin = array(
                    "f_name" =>  $f_name,
                    "l_name" =>  $l_name,
                    "mobile_number" =>  $mobile_number,
                    "email_address" =>  $email_address,
                    "current_password" =>  $current_password,
                    "password" =>  $password,
                    "c_password" =>  $c_password,
                    "profile_img_file" =>  $profile_img_file
                );

                $this -> validate_user_data();
            }
            // var_dump($this -> admin);
        }
        public function validate_user_data(){
            if(isset($_POST) && count($_POST) > 0){
                global $connect;
                global $Generic;
                $admin = $this -> admin;
                $admin_id = json_decode($_COOKIE["PEA"]) -> id;

                if(isset($admin["profile_img_file"])){
                    $ext_arr = ["jpeg", "jpg", "png", "gif"];
                    $ext = strtolower(explode(".", $admin["profile_img_file"]["name"])[1]);
                    $admin_folder = "img/admin/" . $admin_id . "/";
                    $new_location = $admin_folder . strtolower($Generic -> randomTextGen(10)) . "." . $ext;

                    if(!file_exists("../../../" . $admin_folder)){
                        mkdir("../../../" . $admin_folder);
                    }
                }

                if(strlen($admin["f_name"]) > 50 || strlen($admin["f_name"]) < 1){
                    $this -> response(
                        "error",
                        "First name is too long or short."
                    );
                }
                elseif($Generic -> forbiddenChars($admin["f_name"], "name")){
                    $this -> response(
                        "error",
                        "First name contains unwanted characters (Max. 50 characters)."
                    );
                }

                elseif(strlen($admin["l_name"]) > 50 || strlen($admin["l_name"]) < 1){
                    $this -> response(
                        "error",
                        "Last name is too long or short."
                    );
                }
                elseif($Generic -> forbiddenChars($admin["l_name"], "name")){
                    $this -> response(
                        "error",
                        "Last name contains unwanted characters (Max. 50 characters)."
                    );
                }

                elseif(strlen($admin["mobile_number"]) > 20 || strlen($admin["mobile_number"]) < 1){
                    $this -> response(
                        "error",
                        "Mobile number is too long or short (Max. 20 characters)."
                    );
                }

                elseif($Generic -> forbiddenChars($admin["mobile_number"], "text")){
                    $this -> response(
                        "error",
                        "Mobile number contains unwanted characters."
                    );
                }

                elseif(strlen($admin["email_address"]) > 100 || strlen($admin["email_address"]) < 1){
                    $this -> response(
                        "error",
                        "Email address is too long or short."
                    );
                }
                elseif(filter_var(filter_var($admin["email_address"], FILTER_SANITIZE_EMAIL), FILTER_VALIDATE_EMAIL) == false){
                    $this -> response(
                        "error",
                        "Email address contains unwanted characters."
                    );
                }

                elseif(strlen($admin["password"]) < 8 && $admin["password"] != ""){
                    $this -> response(
                        "error",
                        "New password is too short."
                    );
                }

                elseif(strlen($admin["password"]) > 100){
                    $this -> response(
                        "error",
                        "New password is too long."
                    );
                }

                elseif($Generic -> forbiddenChars($admin["password"], "password") && $admin["password"] != ""){
                    $this -> response(
                        "error",
                        "New password contains unwanted characters."
                    );
                }

                elseif($admin["password"] != "" && ($admin["password"] !== $admin["c_password"])){
                    $this -> response(
                        "error",
                        "New passwords do not match."
                    );
                }

                elseif($admin["profile_img_file"] != null && !is_file($admin["profile_img_file"]["tmp_name"])){
                    $this -> response(
                        "error",
                        "Profile image is not a regular file."
                    );
                }

                elseif($admin["profile_img_file"] != null && !array_search(explode(".", strtolower($admin["profile_img_file"]["name"]))[1], $ext_arr)){
                    $this -> response(
                        "error",
                        "Profile image format is not supported."
                    );

                    $files_in_directory = scandir("../../../" . $admin_folder);
                    foreach ($files_in_directory as $key => $value) {
                        if(is_file("../../../" . $admin_folder . $value)){
                            unlink("../../../" . $admin_folder . $value);
                        }
                    }
                }

                // elseif($product_img["size"] > 1000000){
                    // 1MB?
                    // $response["type"] = "error";
                    // $response["message"] = "Product image size is too large.";
                // }



                elseif($admin["profile_img_file"] != null && !move_uploaded_file($admin["profile_img_file"]["tmp_name"], "../../../" . $new_location)){
                    $this -> response(
                        "error",
                        "Product image upload failed."
                    );
                }

                else{
                    $f_name = $admin["f_name"];
                    $l_name = $admin["l_name"];
                    $mobile_number = $admin["mobile_number"];
                    $email_address = $admin["email_address"];
                    $current_password = md5($admin["current_password"]);
                    $password = $admin["password"];

                    $query = $connect -> query(
                        "SELECT * FROM admin WHERE id = '$admin_id' AND password = '$current_password'"
                    );

                    if($query -> num_rows > 0){
                        $sql = "UPDATE admin SET f_name = '$f_name', l_name = '$l_name', mobile_number = '$mobile_number', email = '$email_address'";

                        if(strlen($password) > 7){
                            $password = md5($password);
                            $sql .= ", password = '$password'";
                        }
                        if(isset($new_location)){
                            $sql .= ", profile_img = '$new_location'";
                        }

                        $sql .= " WHERE id = '$admin_id'";

                        $query = $connect -> query($sql);

                        if($query === TRUE){
                            $this -> response(
                                "success",
                                "User data updated successfully."
                            );

                            $_POST = null;
                            $_FILES = null;
                        }
                        else{
                            $this -> response(
                                "error",
                                "Passwords do not match."
                            );
                        }
                    }
                    else{
                        $this -> response(
                            "error",
                            "Current passwords seems incorrect. Try again."
                        );
                    }
                }
            }
        }
        private function response($type, $message){
            echo json_encode(
                array(
                    "type" => $type,
                    "message" => $message
                )
            );
        }
    }

    $UpdateAdminData = new UpdateAdminData();
?>
