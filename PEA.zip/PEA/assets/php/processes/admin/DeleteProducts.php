<?php

    include '../../init.php';

    class DeleteProducts{
        public function __construct(){
            global $connect;

            if(isset($_POST) && !empty($_POST)){
                $product_ids = $_POST;

                $list = "";

                foreach ($product_ids as $product_id => $key){
                    $list .= "'" . $product_ids[$product_id] . "'";

                    if($product_id < count($product_ids) - 1){
                        $list .= ", ";
                    }
                }

                $product_img_query = $connect -> query("SELECT image FROM products WHERE id IN ($list)");

                if($product_img_query && $product_img_query -> num_rows > 0){
                    while($row = $product_img_query -> fetch_assoc()){
                        $image = $row["image"];
                        if($image != null && file_exists("../../../" . $image)){
                            unlink("../../../" . $image);
                        }
                    }
                }

                $sql_query = "DELETE FROM products WHERE id IN ($list)";

                $query = $connect -> query($sql_query);

                if($query === TRUE){
                    $this -> deleted = TRUE;
                }
                else{
                    $this -> deleted = FALSE;
                }

                $this -> on_delete();
            }
        }

        private function response($type, $message){
            echo json_encode(
                array(
                    "type" => $type,
                    "message" => $message
                )
            );
        }

        public function on_delete(){
            if(isset($_POST) && !empty($_POST)){
                if($this -> deleted){
                    $_POST = null;
                    $this -> response("success", "Products deleted successfully.");
                }
                else{
                    $this -> response("error", "Something went wrong. Try again.");
                }
            }
        }
    }

    $DeleteProducts = new DeleteProducts();

?>
