<?php

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        include '../../init.php';
    }
    // var_dump($_SERVER);

    class ValidateNewProduct{
        public function __construct(){
            if(isset($_POST) && !empty($_POST)){
                global $connect;
                global $Generic;

                $product_id = $Generic -> product_id_gen();
                $product_name = $Generic -> filterInput($_POST["product_name"]);
                $product_qty = $Generic -> filterInput($_POST["product_qty"]);
                $product_category = $Generic -> filterInput($_POST["product_category"]);
                $product_description = $Generic -> filterInput2($_POST["product_description"]);
                $buy_price = $Generic -> filterInput($_POST["buy_price"]);
                $sell_price = $Generic -> filterInput($_POST["sell_price"]);
                $prod_date = $Generic -> filterInput($_POST["prod_date"]);
                $expr_date = $Generic -> filterInput($_POST["expr_date"]);
                $product_img = ((!empty($_FILES["product_img"]["name"])) ? $_FILES["product_img"] : NULL);

                $this -> new_product = array(
                    "product_id" => $product_id,
                    "product_name" => $product_name,
                    "product_qty" => $product_qty,
                    "product_category" => $product_category,
                    "product_description" => $product_description,
                    "buy_price" => $buy_price,
                    "sell_price" => $sell_price,
                    "prod_date" => $prod_date,
                    "expr_date" => $expr_date,
                    "product_img" => $product_img,
                );
                // var_dump($this -> new_product);
                $this -> validate_form_data();
                $_SESSION["form_data"] = $this -> new_product;
            }
        }
        public function validate_form_data(){
            global $Generic;
            global $connect;

            // if(isset($_GET["action"]) && $_GET["action"] === "edit_product"){
            //     $product_id = $_GET["product_id"];
            //
            //     $query = $connect -> query(
            //         "SELECT * FROM products WHERE id = '$product_id'"
            //     );
            //
            //     if($query && $query -> num_rows > 0){
            //         $this -> product_data = $query -> fetch_assoc();
            //         $this -> product_data["image"] = ((file_exists($this -> product_data["image"])) ? $this -> product_data["image"] : "../assets/img/default.png");
            //     }
            //     else{
            //         $this -> product_data = null;
            //     }
            // }

            if(isset($_POST["add_product"])){
                if($this -> new_product == $_SESSION["form_data"]){
                    $response["type"] = "error";
                    $response["message"] = "Product data has already been saved.";
                }
                else{
                    $product_id = $this -> new_product["product_id"];
                    $product_name = $this -> new_product["product_name"];
                    $product_qty = $this -> new_product["product_qty"];
                    $product_category = $this -> new_product["product_category"];
                    $product_description = $this -> new_product["product_description"];
                    $buy_price = $this -> new_product["buy_price"];
                    $sell_price = $this -> new_product["sell_price"];
                    $prod_date = $this -> new_product["prod_date"];
                    $expr_date = $this -> new_product["expr_date"];
                    $product_img = $this -> new_product["product_img"];

                    if(strlen($product_name) > 50 || strlen($product_name) < 1){
                        $response["type"] = "error";
                        $response["message"] = "Product name too short or long (Max. 50 characters).";
                    }
                    elseif($Generic -> forbiddenChars($product_name, "name")){
                        $response["type"] = "error";
                        $response["message"] = "Product name contains unwanted characters.";
                    }

                    elseif(strlen($product_qty) < 1){
                        $response["type"] = "error";
                        $response["message"] = "Product quantity too small.";
                    }
                    elseif($Generic -> forbiddenChars($product_qty, "number")){
                        $response["type"] = "error";
                        $response["message"] = "Product quantity contains unwanted characters.";
                    }

                    elseif($product_category == "_default"){
                        $response["type"] = "error";
                        $response["message"] = "Product category has not been selected.";
                    }

                    elseif(strlen($product_description) > 350){
                        $response["type"] = "error";
                        $response["message"] = "Product description too large (Max. 350 characters).";
                    }

                    elseif(strlen($buy_price) < 1){
                        $response["type"] = "error";
                        $response["message"] = "Buy price too small.";
                    }
                    elseif($Generic -> forbiddenChars($buy_price, "number")){
                        $response["type"] = "error";
                        $response["message"] = "Buy price contains unwanted characters.";
                    }

                    elseif(strlen($sell_price) < 1){
                        $response["type"] = "error";
                        $response["message"] = "Sell price too small.";
                    }
                    elseif($Generic -> forbiddenChars($sell_price, "number")){
                        $response["type"] = "error";
                        $response["message"] = "Sell price contains unwanted characters.";
                    }

                    elseif(!date_create($prod_date)){
                        $response["type"] = "error";
                        $response["message"] = "Production date seems invalid (Date format: mm/dd/yyyy).";
                    }
                    elseif(!date_create($expr_date)){
                        $response["type"] = "error";
                        $response["message"] = "Expiration date seems invalid (Date format: mm/dd/yyyy).";
                    }

                    else{

                        $prod_date = date_create($prod_date);
                        $expr_date = date_create($expr_date);
                        $product_description = ((strlen($product_description) > 0) ? $product_description : NULL);

                        if(date_diff($prod_date, $expr_date) -> invert == 1){
                            $response["type"] = "error";
                            $response["message"] = "Expiration date should be ahead of production date.";
                        }

                        else{

                            if($product_img["tmp_name"] == ""){

                                $admin_id = json_decode($_COOKIE["PEA"]) -> id;

                                $prod_date = date_format($prod_date, "Y-m-d h:i:s");
                                $expr_date = date_format($expr_date, "Y-m-d h:i:s");

                                if(isset($_GET["action_type"]) && $_GET["action_type"] == "update"){
                                    $product_id = $_GET["product_id"];

                                    $query = $connect -> query(
                                    "UPDATE `products` SET `admin_id` = '$admin_id', `name` = '$product_name', `category_id` = '$product_category', `description` = '$product_description', `quantity` = '$product_qty', `buy_price` = '$buy_price', `sell_price` = '$sell_price', `production_date` = '$prod_date', `expiration_date` = '$expr_date' WHERE `id` = '$product_id'"
                                    );

                                    if($query === TRUE){
                                        $_POST = NULL;
                                        $response["type"] = "success";
                                        $response["message"] = "Product updated successfully.";
                                    }
                                    else{
                                        $response["type"] = "error";
                                        $response["message"] = "Could not update product data. Try again!";
                                    }
                                }
                                else{
                                    $stmt = $connect -> prepare(
                                    "INSERT INTO products (`id`, `admin_id`, `name`, `category_id`, `description`, `quantity`, `buy_price`, `sell_price`, `production_date`, `expiration_date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                                    );
                                    $stmt -> bind_param(
                                    "sssssiddss",
                                    $product_id,
                                    $admin_id,
                                    $product_name,
                                    $product_category,
                                    $product_description,
                                    $product_qty,
                                    $buy_price,
                                    $sell_price,
                                    $prod_date,
                                    $expr_date
                                    );

                                    $stmt -> execute();

                                    $_POST = NULL;
                                    $response["type"] = "success";
                                    $response["message"] = "New product added successfully.";
                                }
                            }
                            else{

                                $ext_arr = ["jpeg", "jpg", "png", "gif"];
                                $ext = strtolower(explode(".", $product_img["name"])[1]);
                                $new_location = "img/products/" . time() . "." . $ext;

                                if(!is_file($product_img["tmp_name"])){
                                    $response["type"] = "error";
                                    $response["message"] = "Product image is not a regular file.";
                                }
                                elseif(!array_search(explode(".", strtolower($product_img["name"]))[1], $ext_arr)){
                                    $response["type"] = "error";
                                    $response["message"] = "Product image format is not supported.";
                                }
                                // elseif($product_img["size"] > 1000000){
                                // 1MB?
                                // $response["type"] = "error";
                                // $response["message"] = "Product image size is too large.";
                                // }
                                elseif(!move_uploaded_file($product_img["tmp_name"], "../../../" . $new_location)){
                                    $response["type"] = "error";
                                    $response["message"] = "Product image upload failed.";
                                }
                                else{
                                    $admin_id = json_decode($_COOKIE["PEA"]) -> id;

                                    $prod_date = date_format($prod_date, "Y-m-d h:i:s");
                                    $expr_date = date_format($expr_date, "Y-m-d h:i:s");

                                    if(isset($_GET["action_type"]) && $_GET["action_type"] == "update"){
                                        $query = $connect -> query(
                                        "UPDATE `products` SET `admin_id` = '$admin_id', `name` = '$product_name', `category_id` = '$product_category', `description` = '$product_description', `quantity` = '$product_qty', `image` = '$new_location', `buy_price` = '$buy_price', `sell_price` = '$sell_price', `production_date` = '$prod_date', `expiration_date` = '$expr_date' WHERE `id` = '$product_id'"
                                        );

                                        if($query === TRUE){
                                            $_POST = NULL;
                                            $response["type"] = "success";
                                            $response["message"] = "Product updated successfully.";
                                        }
                                        else{
                                            $response["type"] = "error";
                                            $response["message"] = "Could not update product data. Try again!2";
                                        }
                                    }
                                    else{
                                        $stmt = $connect -> prepare(
                                        "INSERT INTO products (`id`, `admin_id`, `name`, `category_id`, `description`, `quantity`, `image`, `buy_price`, `sell_price`, `production_date`, `expiration_date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                                        );
                                        $stmt -> bind_param(
                                        "sssssisddss",
                                        $product_id,
                                        $admin_id,
                                        $product_name,
                                        $product_category,
                                        $product_description,
                                        $product_qty,
                                        $new_location,
                                        $buy_price,
                                        $sell_price,
                                        $prod_date,
                                        $expr_date
                                        );

                                        $stmt -> execute();

                                        $_POST = NULL;
                                        $response["type"] = "success";
                                        $response["message"] = "New product added successfully.";
                                    }
                                }
                            }
                        }
                    }
                }

                $this -> response($response["type"], $response["message"]);
            }
            // else{
            //     $this -> response("success", "Data has already been submitted to database.");
            //     header("Location: add_product.php");
            // }
        }

        public function on_success(){
            if(isset($_SESSION["message"])){
                $message = $_SESSION["message"];
                $_SESSION["message"] = NULL;

                return $this -> response("success", $message);
            }
        }

        private function response($type, $message){
            echo json_encode(
                array(
                    "type" => $type,
                    "message" => $message
                )
            );
        }

        public function format_date($date, $format){
            if(date_create($date)){
                return date_format(date_create($date), $format);
            }
            else{
                return "";
            }
        }

        public function is_set($var){
            return ((isset($var)) ? $var : "");
        }

        public function validate_image($img_src){
            if(file_exists($img_src)){
                return $img_src;
            }
            else{
                return "../assets/img/corrupt_img.png";
            }
        }
    }

    $ValidateNewProduct = new ValidateNewProduct();

?>
