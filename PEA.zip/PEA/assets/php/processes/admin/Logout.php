<?php

    if(isset($_POST["logout"])){
        setcookie(
            "PEA",
            null,
            (time() - (365 * 3600)),
            "/"
        );
        header("Location: ../base");
    }
    elseif(isset($_POST["cancel"])){
        header("Location: index.php");
    }

?>
