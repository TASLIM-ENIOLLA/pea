<?php

    class LoadExpiringProducts{
        public $row_length = 0;
        public function __construct(){
            global $connect;

            $now = date("Y-m-d h:i:s");
            $one_weeks_time = date("Y-m-d h:i:s", strtotime("+1 year"));

            $query = $connect -> query(
                "SELECT *, `products`.`id` AS prod_id, `products`.`name` AS prod_name, `category`.`name` AS cat_name FROM products INNER JOIN category ON `category`.`id` = `products`.`category_id` WHERE `expiration_date` BETWEEN '" . $now . "' AND '" . $one_weeks_time . "' ORDER BY `products`.`date_created` DESC"
            );

            $this -> row_length = $query -> num_rows;
            $this -> query = $query;
        }
        public function render(){

            if($this -> row_length > 0){
                $rows = 0;
                $res = '
                    <div>
                        <div class = "pb-2 bold">Retrieved <span id = "record-returned">' . $this -> row_length . '</span> out of <span id = "record-total">' . $this -> row_length . '</span> record(s)</div>
                        <div class = "pb-2 bold">Products expiring in one month.</div>
                    </div>
                    <div id = "product-list" class = "flex-1 overflow-y-auto">
                ';
                while($row = $this -> query -> fetch_assoc()){
                    $row["image"] = (($row["image"] == null) ? "../assets/img/default.png" : ((file_exists("../assets/" . $row["image"])) ? "../assets/" . $row["image"] : "../assets/img/default.png"));
                    $res .= '
                        <div
                            class="border-bottom animated fadeIn p-3 mb-3 flex-h cursor-pointer flicker transit" style="animation-delay: 0.1s;" data-id = "' . $row["prod_id"] . '" data-name = "' . $row["prod_name"] . '" data-category = "' . $row["cat_name"] . '">
                            <div class = "flex-1 flex-h">
                                <a href = "view_product.php?product_id=' . $row["prod_id"] . '">
                                    <div class="border shadow rounded" style="width: 60px; height: 60px; borderradius: 50%; background: url(' . $row["image"] . ') center center / cover, lightgrey;"></div>
                                </a>
                                <label for = "' . $rows . '" class="flex-1 pl-3">
                                    <div class="w-100 flex-h">
                                        <div class="flex-1 flex-h">
                                            <span class="text-capitalize text-dark flex-1 single-line expandables">
                                                <span class="bold">' . $row["prod_name"] . '</span> | <span>' . $row["cat_name"] . '</span>
                                            </span>
                                        </div>
                                        <div>
                                            <span class="bold text-uppercase theme-color">₦' . $row["sell_price"] . '</span>
                                        </div>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize bold text-success flex-1 single-line expandables">Production Date: ' . date("M Y", strtotime($row["production_date"])) . '</span>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize bold text-danger flex-1 single-line expandables">Expiration Date: ' . date("M Y", strtotime($row["expiration_date"])) . '</span>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize text-secondary flex-1 single-line expandables">Qty in stock: ' . $row["quantity"] . '</span>
                                    </div>
                                </label>
                            </div>
                        </div>
                    ';

                    $rows++;
                }

                return $res;
            }
            else{
                return '
                    <div class = "w-100">
                        <div class = "p-5 my-5 text-secondary mx-auto col-12 bg-light shadow-sm rounded text-c bold">
                            Expiring product list is empty! No expiring products for the mean time.
                        </div>
                    </div>
                ';
            }
        }
    }

    $LoadExpiringProducts = new LoadExpiringProducts();

?>
