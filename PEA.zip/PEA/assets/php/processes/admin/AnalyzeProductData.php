<?php

    class AnalyzeProductData{
        public function chartData(){
            global $connect;
            $this -> chartData = [];
            $now = date("Y-m-d h:i:s");
            $five_years_time = date("Y-m-d h:i:s", strtotime("+5 years"));

            $query = $connect -> query(
                "SELECT * FROM `products` WHERE `expiration_date` BETWEEN '" . $now . "' AND '" . $five_years_time . "'"
            );

            if($query -> num_rows > 0){
                while($rows = $query -> fetch_assoc()){
                    $rrr = $rows["expiration_date"];
                    $qty = $rows["quantity"];

                    array_push(
                        $this -> chartData,
                        array(
                            "Y" => date("Y", strtotime($rrr)),
                            "m" => date("m", strtotime($rrr)),
                            "d" => date("d", strtotime($rrr)),
                            "qty" => $qty
                        )
                    );
                }
            }
            else{
                array_push(
                    $this -> chartData,
                    array()
                );
            }
            return json_encode($this -> chartData);
        }
        public function donutData(){
            global $connect;
            $this -> donutData = [];

            $query = $connect -> query(
                "SELECT * FROM `products`"
            );

            if($query -> num_rows > 0){
                while($rows = $query -> fetch_assoc()){
                    $rrr = $rows["expiration_date"];
                    $qty = $rows["quantity"];

                    array_push(
                        $this -> donutData,
                        array(
                            "Y" => date("Y", strtotime($rrr)),
                            "m" => date("m", strtotime($rrr)),
                            "d" => date("d", strtotime($rrr)),
                            "qty" => $qty
                        )
                    );
                }
            }
            else{
                array_push(
                    $this -> donutData,
                    array()
                );
            }
            return json_encode($this -> donutData);
        }
        public function product_count(){
            global $connect;

            $query = $connect -> query(
                "SELECT SUM(quantity) AS product_count FROM `products`"
            );

            if($query -> num_rows > 0){
                $product_count = $query -> fetch_assoc()["product_count"];

                return $product_count;
            }
        }
        public function format_number_with_commas($number){
            if(strlen($number) > 3){
                $number = str_split($number);
                $res = "";

                for($x = count($number) - 1; $x >= 0; $x--){
                    $res = $number[$x] . $res;
                    if((count($number) - $x) % 3 == 0){
                        $res = "," . $res;
                    }
                }

                return $res;
            }
            else{
                return $number;
            }
        }
    }

    $AnalyzeProductData = new AnalyzeProductData();

?>
