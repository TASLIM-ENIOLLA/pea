function onClick(element) {
	return new Promise(
		(res) => {
			element.addEventListener(
				"click",
				res
			);
		}
	);
}

class FrostedDialog{
	constructor(parameterObject){
		this.parameterObject = parameterObject;
		this.regularizeParameterObject(this.parameterObject);
	}
	regularizeParameterObject(parameterObject) {
		if(typeof(parameterObject) != "object"){
			parameterObject = {};
		}
		if(parameterObject["type"] == undefined){
			parameterObject["type"] = "alert";
		}
		if(parameterObject["title"] == undefined){
			parameterObject["title"] = "Frosted Dialog";
		}
		if(parameterObject["info"] == undefined){
			parameterObject["info"] = "";
		}
		if(parameterObject["acceptText"] == undefined){
			parameterObject["acceptText"] = "Accept";
		}
		if(parameterObject["declineText"] == undefined){
			parameterObject["declineText"] = "Cancel";
		}
		if(parameterObject["promptDefaultValueText"] == undefined){
			parameterObject["promptDefaultValueText"] = "";
		}
		if(parameterObject["acceptCallback"] == undefined){
			parameterObject["acceptCallback"] = () => {
				this.closeFrostedDialog();
			}
		}
		if(parameterObject["declineCallback"] == undefined){
			parameterObject["declineCallback"] = () => {
				this.closeFrostedDialog();
			}
		}
		this.parameterObject = parameterObject;
	}

	createFrostedDialogDisplay(parameterObject) {
		let a = document.createElement("div");
		a.className = "po-abs top-0 left-0 vh100 vw100 flex-v j-c-c a-i-c animated fadeIn";
		a.id = "frostedDialog";
		a.style = "background: rgba(0, 0, 0, .7);";
		document.body.appendChild(a); {
			let b = document.createElement("div");
			b.className = "bg-white shadow flex-v rounded-lg overflow-0";
			b.style = "width: 65%; max-width: 400px; max-height: 80%;";
			a.appendChild(b); {
				let c = document.createElement("div");
				c.className = "frosted-dialog-title text-c flex-h theme-bg p-3 border-bottom";
				b.appendChild(c); {
					let d = document.createElement("span");
					d.className = "flex-1 text-capitalize single-line bold letter-spacing-1 text-white";
					d.innerHTML = parameterObject["title"];
					d.style = "font-size: 16px;";
					c.appendChild(d);
				}
				let e = document.createElement("div"); this.frostedDialogBodyNode = e;
				e.className = "overflow-y-auto frosted-dialog-body p-3";
				e.style = "min-height: 60px; font-size: 16px;";
				b.appendChild(e);
				let f = document.createElement("div"); this.frostedDialogOptionsNode = f;
				f.className = "flex-h border-top pt-2 user-select-0 frosted-dialog-options p-3";
				b.appendChild(f); {
					// let g = document.createElement("div");
					// g.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-accept";
					// g.tabindex = "1";
					// f.appendChild(g); {
					// 	let h = document.createElement("span");
					// 	h.className = "flex-1 single-line user-select-0 text-capitalize text-c text-primary bold letter-spacing-1";
					// 	h.innerHTML = parameterObject["acceptText"];
					// 	g.appendChild(h);
					// }
					// if(parameterObject.type != "alert"){
					// 	let i = document.createElement("span");
					// 	i.className = "br py-1";
					// 	f.appendChild(i);
					// 	let j = document.createElement("div");
					// 	j.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-decline";
					// 	j.tabindex = "1";
					// 	f.appendChild(j); {
					// 		let k = document.createElement("span");
					// 		k.className = "flex-1 single-line user-select-0 text-capitalize text-c text-primary bold letter-spacing-1";
					// 		k.innerHTML = parameterObject["declineText"];
					// 		j.appendChild(k);
					// 	}
					// }
				}
			}
		}
	}
	alert(text){
		this.remove();
		this.createFrostedDialogDisplay(this.parameterObject);

		let frostedDialogBodyNode = this.frostedDialogBodyNode;
		let frostedDialogOptionsNode = this.frostedDialogOptionsNode;

		let a = document.createElement("div");
		a.className = "p-2 text-l bold text-secondary";
		a.innerHTML = text;
		frostedDialogBodyNode.appendChild(a);

		let g = document.createElement("div");
		g.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-accept";
		g.tabindex = "1";
		frostedDialogOptionsNode.appendChild(g); {
			let h = document.createElement("span");
			h.className = "flex-1 pointer-events-0 single-line user-select-0 text-capitalize text-c text-primary bold letter-spacing-1";
			h.innerHTML = this.parameterObject["acceptText"];
			g.appendChild(h);
		}
		return Promise.all([onClick(g)]);
	}
	confirm(text){
		this.remove();
		this.createFrostedDialogDisplay(this.parameterObject);

		let frostedDialogBodyNode = this.frostedDialogBodyNode;
		let frostedDialogOptionsNode = this.frostedDialogOptionsNode;

		let a = document.createElement("div");
		a.className = "p-2 text-l bold text-secondary";
		a.innerHTML = text;
		frostedDialogBodyNode.appendChild(a);

		let g = document.createElement("div");
		g.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-accept";
		g.tabindex = "1";
		g.id = "accept";
		frostedDialogOptionsNode.appendChild(g); {
			let h = document.createElement("span");
			h.className = "flex-1 pointer-events-0 single-line user-select-0 text-capitalize text-c text-primary bold letter-spacing-1";
			h.innerHTML = this.parameterObject["acceptText"];
			g.appendChild(h);
		}
		let i = document.createElement("span");
		i.className = "br py-1";
		frostedDialogOptionsNode.appendChild(i);
		let j = document.createElement("div");
		j.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-decline";
		j.tabindex = "1";
		j.id = "decline";
		frostedDialogOptionsNode.appendChild(j); {
			let k = document.createElement("span");
			k.className = "flex-1 pointer-events-0 single-line user-select-0 text-capitalize text-c text-danger bold letter-spacing-1";
			k.innerHTML = this.parameterObject["declineText"];
			j.appendChild(k);
		}

		return new Promise(
			(a) => {
				onClick(g).then(
					() => {
						this.remove();
						a(true);
					}
				);
				onClick(j).then(
					() => {
						this.remove();
						a(false);
					}
				);
			}
		);
	}
	prompt(obj){
		let info = obj.promptText || "";
		let placeholdText = obj.placeholdText || null;
		let type = obj.type || "text";

		this.remove();
		this.createFrostedDialogDisplay(this.parameterObject);

		let frostedDialogBodyNode = this.frostedDialogBodyNode;
		let frostedDialogOptionsNode = this.frostedDialogOptionsNode;

		let a = document.createElement("div");
		a.className = "flex-v p-2 text-l bold text-secondary";
		a.innerHTML = info;
		frostedDialogBodyNode.appendChild(a); {
			let a1 = document.createElement("div");
			a1.className = "pb-2 flex-1";
			a.appendChild(a1);

			var a2 = document.createElement("input");
			a2.className = "d-block text-secondary outline-0 p-2 rounded w-100 border border-primary";
			a2.type = type;
			a2.placeholder = "Type here...";
			if(!placeholdText){
				a2.value = placeholdText;
			}
			a.appendChild(a2);
		}

		let g = document.createElement("div");
		g.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-accept";
		g.tabindex = "1";
		g.id = "accept";
		frostedDialogOptionsNode.appendChild(g); {
			let h = document.createElement("span");
			h.className = "flex-1 border-right pointer-events-0 single-line user-select-0 text-capitalize text-c text-primary bold letter-spacing-1";
			h.innerHTML = "Done";
			g.appendChild(h);
		}
		let i = document.createElement("span");
		i.className = "br py-1";
		frostedDialogOptionsNode.appendChild(i);
		let j = document.createElement("div");
		j.className = "flex-1 flex-h j-c-c a-i-c px-2 py-1 cursor-pointer tap outline-0 frosted-dialog-option-decline";
		j.tabindex = "1";
		j.id = "decline";
		frostedDialogOptionsNode.appendChild(j); {
			let k = document.createElement("span");
			k.className = "flex-1 border-left pointer-events-0 single-line user-select-0 text-capitalize text-c text-danger bold letter-spacing-1";
			k.innerHTML = this.parameterObject["declineText"];
			j.appendChild(k);
		}

		return new Promise(
			(a) => {
				onClick(g).then(
					() => {
						this.remove();
						a(a2.value);
					}
				);
				onClick(j).then(
					() => {
						this.remove();
						a(false);
					}
				);
			}
		);
	}
	remove(){
		if(document.querySelector("#frostedDialog")){
			document.querySelector("#frostedDialog").remove();
		}
	}
}

var frostedDialog = new FrostedDialog({
	title: "Product Expiration Alerter"
});
