function delete_product(e){
    if(confirm("Are you sure you want to delete product? Action is irreversible.")){
        let product_id = e.getAttribute("data-product-id");
        let xmlHtttp = new XMLHttpRequest();

        xmlHtttp.onreadystatechange = function(){
            if(xmlHtttp.readyState == 4 && xmlHtttp.status == 200){
                let responseText = JSON.parse(xmlHtttp.responseText);
                if(responseText.type == "success"){
                    window.location.replace("all_products.php");
                }
                else{
                    toast("Couldn't delete product! Try again.", "danger");
                }
            }
        };
        xmlHtttp.open(
            "POST",
            "../assets/php/processes/admin/DeleteProducts.php",
            true
        );
        xmlHtttp.setRequestHeader(
            "Content-type",
            "application/x-www-form-urlencoded"
        );
        xmlHtttp.send("product_id=" + product_id);
    }
}
