class Index{
    initiator(){
        window.addEventListener(
            "load",
            () => {
                let location = window.location.toString();
                location = location.replace(window.location.hash, "");
                location = location.replace(window.location.search, "");
                location = location.split("/");

                if(location[location.length - 1] != "" && document.querySelector("[href = '" + location[location.length - 1] + "']")){
                    document.querySelectorAll("[href = '" + location[location.length - 1] + "']").forEach(
                        item => {
                            item.classList.add("active-menu-item");
                        }
                    );
                }
                // else{
                //     document.querySelectorAll(".menu-item-list > a:first-child").forEach(
                //         item => {
                //             item.classList.add("active-menu-item");
                //         }
                //     );
                // }
            }
        );

        document.querySelector("#mobile-menu-toggle").addEventListener(
            "click",
            (e) => {
                new Index().open_close_mobile_menu();
            }
        );

        document.querySelector("#main-section").onpointerdown = (e) => {
            this.open_close_mobile_menu(true);
        }

        document.querySelector("#mobile-menu").innerHTML =
            document.querySelector("#main-menu").innerHTML;

    }

    open_close_mobile_menu(state = null){
        let mobile_menu = document.querySelector("#mobile-menu");
        let mobile_menu_toggle = document.querySelector("#mobile-menu-toggle");

        if(state != null){
            if(state){
                mobile_menu.classList.replace("col-5", "col-0");
                mobile_menu_toggle.classList.replace("icon-close", "icon-bars");
            }
            else{
                mobile_menu_toggle.classList.replace("icon-bars", "icon-close");
                mobile_menu.classList.replace("col-0", "col-5");
            }
        }
        else{
            if(mobile_menu.classList.contains("col-5")){
                this.open_close_mobile_menu(true);
            }
            else{
                this.open_close_mobile_menu(false);
            }
        }
    }
}

new Index().initiator();


function Toast(message, background = "light", duration = 4000){
    return new Index().toast(message, background, duration);
}
