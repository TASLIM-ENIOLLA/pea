class AddProduct{
    constructor(){
        document.querySelectorAll("input, textarea, select").forEach(
            item => {
                item.addEventListener(
                    "input",
                    () => {
                        if(document.querySelector("input[name = 'add_product']").classList.contains("disabled")){
                            document.querySelector("input[name = 'add_product']").classList.remove("disabled");
                        }
                    }
                );
            }
        );
        document.querySelector("input[name = 'add_product']").addEventListener(
            "click",
            (e) => {
                let formData = new FormData();

                e.srcElement.form.onsubmit = (f) => {
                    f.preventDefault();
                }
                // console.log(e.srcElement.form.querySelectorAll("input"))
                e.srcElement.form.querySelectorAll("input, textarea, select").forEach(
                    item => {
                        if(item.type == "file" && item.files.length > 0){
                            console.log(item);
                            formData.append(item.name, item.files[0])
                        }
                        else{
                            formData.append(item.name, item.value)
                        }
                    }
                );
                let get_query = e.srcElement.form.action.split("?")[1] || "";
                let xmlHtttp = new XMLHttpRequest();
                xmlHtttp.onreadystatechange = function(){
                    if(this.readyState == 4 && this.status == 200){
                        try{
                            let responseText = JSON.parse(this.responseText);
                            toast(responseText.message, ((responseText.type == "error") ? "danger" : "primary"));
                            e.srcElement.classList.add("disabled");
                        }
                        catch(e){
                            toast("An error occured", "danger", 5000)
                        }

                    }
                };
                xmlHtttp.open(
                    "POST",
                    "../assets/php/processes/admin/ValidateNewProduct.php" + "?" + get_query,
                    true
                );
                xmlHtttp.send(formData);
            }
        );

        document.querySelector("input[name = 'product_img']").oninput = (e) => {
            var reader = new FileReader();
            reader.onload = () => {
                var dataURL = reader.result;
                var output = document.querySelector("#preview_img");
                output.src =
                    dataURL;
            }
            reader.readAsDataURL(e.srcElement.files[0]);
        }
    }
}

var addProduct = new AddProduct();
