try{

    class AllProducts{
        constructor(){
            this.product_list_JSON = window.product_list_JSON;

            document.querySelector("#search").addEventListener(
                "click",
                this.make_search
            );

            [document.querySelector("#search_query"), document.querySelector("#search_category")].forEach(
                item => {
                    item.addEventListener(
                        "input",
                        this.make_search
                    );
                }
            );

            document.querySelector("#delete_products").addEventListener(
                "click",
                (e) => {
                    e.srcElement.form.onsubmit = (f) => {
                        f.preventDefault();
                    }

                    let res = 1;
                    let selectedCheckboxCount = 0;
                    let formData = new FormData();

                    document.querySelectorAll("input[type='checkbox']").forEach(
                        item => {
                            if(item.checked){
                                res *= 0;
                                selectedCheckboxCount++;
                                formData.append(item.name, item.value);
                            }
                        }
                    );

                    if(res == 0){
                        if(confirm("Do you want to delete these product(s)?\nNo. of product(s) to delete: " + selectedCheckboxCount)){
                            let xmlHtttp = new XMLHttpRequest();

                            xmlHtttp.onreadystatechange = () => {
                                if(xmlHtttp.readyState == 4 && xmlHtttp.status == 200){
                                    console.log(xmlHtttp.responseText)
                                    try{
                                        let responseText = JSON.parse(xmlHtttp.responseText);
                                        toast(responseText.message, ((responseText.type == "error") ? "danger" : "primary"));
                                        formData.forEach(
                                            item => {
                                                document.querySelector("input[value = '" + item + "']").parentElement.parentElement.remove();
                                            }
                                        );

                                        document.querySelector("#record-total").innerHTML = document.querySelector("#record-returned").innerHTML = parseInt(document.querySelector("#record-returned").innerHTML) - selectedCheckboxCount;

                                        this.product_list_JSON = product_list_JSON = document.querySelectorAll("#product-list > div");
                                    }
                                    catch(e){
                                        toast("An error occured", "danger");
                                    }
                                }
                            };
                            xmlHtttp.open(
                                "POST",
                                "../assets/php/processes/admin/DeleteProducts.php",
                                true
                            );
                            xmlHtttp.send(formData);
                        }
                    }
                    else{
                        alert("No product has been selected.")
                    }


                }
            );
        }

        make_search = () => {
            let search_query = document.querySelector("#search_query").value.toString().toLowerCase();
            let search_category = document.querySelector("#search_category").value;

            if(search_query.length < 1){
                let product_list_JSON = this.product_list_JSON;

                document.querySelector("#record-returned").innerHTML = product_list_JSON.length;

                document.querySelectorAll("#product-list > div").forEach(
                    item => {
                        item.remove();
                    }
                );

                for(let product in product_list_JSON){
                    if(product == 0 || Number(product)){
                        product = product_list_JSON[product];
                        document.querySelector("#product-list").appendChild(product);
                    }
                }
            }
            else{
                let search_result = [];
                this.product_list_JSON.forEach(
                    item => {
                        let search_string = item.dataset[search_category].toString().toLowerCase();

                        if(new RegExp(search_query).test(search_string)){
                            search_result.push(item);
                        }
                    }
                );

                document.querySelector("#record-returned").innerHTML = search_result.length;

                document.querySelectorAll("#product-list > div").forEach(
                    item => {
                        item.remove();
                    }
                );

                if(search_result.length > 0){
                    search_result.forEach(
                        item => {
                            document.querySelector("#product-list").appendChild(item);
                        }
                    );
                }
                else{
                    let item = document.createElement("div");
                    item.className = "mt-5 mb-3 p-5 bg-light shadow-sm bold text-secondary border border-grey rounded text-c col-11 mx-auto";
                    item.innerText = "Oops! No product found.";

                    document.querySelector("#product-list").appendChild(item);
                }
            }
        }
    }

    new AllProducts();
}
catch(e){
    console.warn(e)
}
