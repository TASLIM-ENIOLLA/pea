class Analytics{
    constructor(){
        window.addEventListener(
            "load",
            () => {
                let morris_area_chart_dataset = areaChartData();
                let morris_donut_chart_dataset = donutChartData();

                this.populate_area_chart(morris_area_chart_dataset);
                this.populate_donut_chart(morris_donut_chart_dataset);
            }
        );
    }

    populate_area_chart = (data) => {
        let normalized_data = this.normalize_area_chart_data(data);

        Morris.Area({
            element: 'morris-area-chart',
            data: normalized_data,
            xkey: 'period',
            ykeys: [
                'product_quantity'
            ],
            labels: [
                'Number of products to expire'
            ],
            pointSize: 5,
            hideHover: 'auto',
            resize: true
        });
    }

    normalize_area_chart_data = (data) => {
        let aggr = {};
        let aggrs = [];

        for(let each in data){
            each = data[each]
            let dd = "";
            if(each.m > 0 && each.m < 4){
                dd = "Q1";
            }
            else if(each["m"] > 3 && each["m"] < 7){
                dd = "Q2";
            }
            else if(each["m"] > 6 && each["m"] < 10){
                dd = "Q3";
            }
            else if(each["m"] > 9 && each["m"] < 13){
                dd = "Q4";
            }

            if(aggr[each["Y"] + " " + dd] == null){
                aggr[each["Y"] + " " + dd] = Number(each["qty"]);
            }
            else{
                aggr[each["Y"] + " " + dd] = Number(aggr[each["Y"] + " " + dd]) + Number(each["qty"]);
            }
        }

        for(let e in aggr){
            aggrs.push({
                "period" : e,
                "product_quantity" : aggr[e]
            });
        }

        return aggrs;
    }

    normalize_donut_chart_data = (data) => {
        let aggr = {
            "Valid products quantity" : 0,
            "Expiring products quantity" : 0,
            "Expired Products quantity" : 0
        };
        let aggrs = [];
        let today = Date.parse(Date());

        for(let each in data){
            each = data[each]
            let date = Date.parse(new Date(each.m + "/" + each.d + "/" + each.Y));

            if(date > today){
                let diff = date - today;
                diff = (((((diff / 1000) / 60) / 60) / 24) / 7 / 4);

                if(diff >= 1){
                    aggr["Valid products quantity"] = Number(aggr["Valid products quantity"]) + Number(each.qty);
                }
                else{
                    aggr["Expiring products quantity"] = Number(aggr["Expiring products quantity"]) + Number(each.qty);
                }
            }
            else{
                aggr["Expired Products quantity"] = Number(aggr["Expired Products quantity"]) + Number(each.qty);
            }
        }

        for(let e in aggr){
            aggrs.push({
                "label" : e,
                "value" : aggr[e]
            });
        }

        return aggrs;
    }

    populate_donut_chart = (data) => {
        let normalized_data = this.normalize_donut_chart_data(data);

        Morris.Donut({
            element: 'morris-donut-chart',
            data: normalized_data,
            resize: true
        });
    }
}

const $Analytics = new Analytics();
