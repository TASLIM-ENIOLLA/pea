<?php

    if(isset($_COOKIE['PEA'])){
        header('Location: admin/');
    }
    else{
        header('Location: base/');
    }

?>
