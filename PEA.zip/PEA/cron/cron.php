<?php

    // $curl = curl_init();
    //
    // $authorization = json_encode(array(
    //     "taslimeniolla" => "Aderibigbe1904$"
    // ));
    // echo $authorization;
    //
    // curl_setopt_array($curl, array(
    // CURLOPT_URL => 'https://vjlnmp.api.infobip.com/sms/2/text/advanced',
    // CURLOPT_RETURNTRANSFER => true,
    // CURLOPT_ENCODING => '',
    // CURLOPT_MAXREDIRS => 10,
    // CURLOPT_TIMEOUT => 0,
    // CURLOPT_FOLLOWLOCATION => true,
    // CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    // CURLOPT_CUSTOMREQUEST => 'POST',
    // CURLOPT_POSTFIELDS =>'
    //     {
    //         "messages": [
    //             {
    //                 "from": "TASLIMENIOLA",
    //                 "destinations": [
    //                     {
    //                         "to": "2347084712978"
    //                     }
    //                 ],
    //                 "text": "This is a sample message"
    //             }
    //         ]
    //     }
    // ',
    // CURLOPT_HTTPHEADER => array(
    //     'Authorization: Basic ' . $authorization,
    //     'Content-Type: application/json',
    //     'Accept: application/json'
    // ),
    // ));
    //
    // $response = curl_exec($curl);
    //
    // curl_close($curl);
    // echo $response;
    //
    // $curl = curl_init();
    //
    // curl_setopt_array($curl, array(
    //     CURLOPT_URL => 'https://vjlnmp.api.infobip.com/sms/1/text/query?username=%7Btaslimeniolla%7D&password=%7BAderibigbe2001%24%7D&from=InfoSMS&to=2347084712978,41793026834&text=Message%20text&flash=true&transliteration=TURKISH&languageCode=TR&intermediateReport=true&notifyUrl=https://www.example.com&notifyContentType=application/json&callbackData=callbackData&validityPeriod=720&track=URL&trackingType=Custom%20tracking%20type',
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_ENCODING => '',
    //     CURLOPT_MAXREDIRS => 10,
    //     CURLOPT_TIMEOUT => 0,
    //     CURLOPT_FOLLOWLOCATION => true,
    //     CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    //     CURLOPT_CUSTOMREQUEST => 'GET',
    //     CURLOPT_HTTPHEADER => array(
    //         'Accept: application/json'
    //     ),
    // ));
    //
    // $response = curl_exec($curl);
    //
    // curl_close($curl);
    // echo $response;

            /********************************************************/
            /*                                                      */
            /*                                                      */
            /*          CRON JOB IS SET TO RUN ONCE A WEEK          */
            /*                                                      */
            /*                                                      */
            /********************************************************/

    include "../assets/php/init.php";

    $now = date("Y-m-d h:i:s");
    $one_weeks_time = date("Y-m-d h:i:s", strtotime("+1 week"));

    $query = $connect -> query(
        "SELECT COUNT(id) AS total FROM `products` WHERE `expiration_date` BETWEEN '" . $now . "' AND '" . $one_weeks_time . "'"
    );

    $query2 = $connect -> query(
        "SELECT SUM(quantity) AS total_quantity FROM `products` WHERE `expiration_date` BETWEEN '" . $now . "' AND '" . $one_weeks_time . "'"
    );

    $query1 = $connect -> query(
        "SELECT id FROM `products` WHERE `expiration_date` BETWEEN '" . $now . "' AND '" . $one_weeks_time . "'"
    );

    if($query/* -> num_rows > 0 && $query1 -> num_rows > 0*/){
        $arr = [];
        $total = $query -> fetch_assoc()["total"];
        $total_quantity = $query2 -> fetch_assoc()["total_quantity"];
        while($row = $query1 -> fetch_assoc()){
            array_push($arr, $row["id"]);
        }
        $total  = number_format($total);
        $total_quantity  = number_format($total_quantity);

        echo "
            <script>
                var product_to_expire_count = \"" . $total . "\" || 0;
                var total_items_to_expire_count = \"" . $total_quantity . "\" || 0;
                var product_to_expire_id_JSON = " . json_encode($arr) . " || [];
                var message = \"Hello PEA admin. This week, a total of " . $total_quantity . " items will be expiring this week, cutting across " . $total . " products. See more at <a>" . $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["SERVER_NAME"] . "/cron/cron.php</a>\";
            </script>
        ";

        echo "Hello PEA admin. This week, a total of " . $total_quantity . " items will be expiring this week, cutting across " . $total . " products. See more at <a href ''>" . $_SERVER["REQUEST_SCHEME"] . "://" . $_SERVER["SERVER_NAME"] . "/cron/cron.php</a>";

    }

?>
<!-- <script src="../assets/js/jquery.js"></script>
<script src="cron.js"></script> -->
