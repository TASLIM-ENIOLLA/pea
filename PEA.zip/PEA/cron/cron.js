var settings = {
    "url": "https://vjlnmp.api.infobip.com/sms/1/text/query?username={taslimeniolla}&password={Aderibigbe1904$}&from=InfoSMS&to=41793026727,41793026834&text=Message text&flash=true&transliteration=TURKISH&languageCode=TR&intermediateReport=true&notifyUrl=https://www.example.com&notifyContentType=application/json&callbackData=callbackData&validityPeriod=720&track=URL&trackingType=Custom tracking type",
    "method": "GET",
    "timeout": 0,
    "headers": {
        "Accept": "application/json"
    },
};

$.ajax(settings).done(function (response) {
    console.log(response);
});
